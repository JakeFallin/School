#include "block.h"

//block constructor
Block:Block(int myStart, int myEnd, bool myBlock) {
	starting = myStart;
	ending = myEnd;
	validBlock = myBlock;
}
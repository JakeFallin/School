#ifndef HELPER_H_
#define HELPER_H_

//helper methods
double getTime(void);
void fibonacci(int num);

#endif